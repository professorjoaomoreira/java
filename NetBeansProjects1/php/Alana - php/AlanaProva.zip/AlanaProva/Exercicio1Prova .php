	<?php

		$A=$_POST['txtAumento'];
		$B=$_POST['txtAumento2'];
		$C=$_POST['txtAumento3'];

		$Aumento=($A+$B+$C)

		if($Aumento=1+10% && $A=3+25% && $B=4+30% && $C=8+50%){
			echo "Seu aumento é de: $Aumento2";
		}else{
			echo "Seu aumento é de: $Aumento3";
			
			
		 
		}
	?>