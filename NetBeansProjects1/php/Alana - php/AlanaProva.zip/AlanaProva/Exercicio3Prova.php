	<?php

	$A=$_POST['txtCodigo1'];
	$B=$_POST['txtCodigo2'];
	$C=$_POST['txtCodigo3'];
	
	$triangulo= $A*$B*$C;
	

	if($A < $B + $C && $B < $A + $C && $C < $A + $B){
	echo "É UM TRIANGULO";
		
	}elseif($A = $B && $B = $C){
	echo "É UM TRIANGULO EQUILÁTERO";
	
	}elseif($A = $B && $A = $C ! $B = $C){
	echo "É UM TRIANGULO ISÓSCELES";
	
	}
	else{
	echo "É UM TRIANGULO ESCALENO";
}

?>