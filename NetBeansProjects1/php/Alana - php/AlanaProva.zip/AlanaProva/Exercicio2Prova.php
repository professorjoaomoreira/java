<?php
    $ano = $_POST['txtano'];
	
	if($ano !/100 && $ano/4 || $ano/100 && $ano/400){
		echo "Este ano é bissexto";
	
	}else
		echo "Este ano não é bissexto";
	