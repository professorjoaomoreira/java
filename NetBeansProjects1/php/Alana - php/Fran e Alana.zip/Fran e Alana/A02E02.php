<?php

$valor = 1;
$final = $_POST["numFinal"];
while ($valor <= $final) {
    if ($valor %2 != 0) {
        echo"<font color='#0099FF'> O valor eh " . $valor . " - impar<br>";
    } else {
        echo"<font color='#009900'> O valor eh " . $valor . " - par<br>";
    }
    $valor++;
}
?>

