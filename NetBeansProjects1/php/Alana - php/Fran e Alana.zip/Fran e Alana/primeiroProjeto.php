<?php

$op = $_POST['OPCAO'];
$valor1 = $_POST['val1'];
$valor2 = $_POST['val2'];

if($op == 'op1'){
echo "O resultado é igual a ", $valor1 + $val2;
}else if($op == 'op2'){
echo "O resultado è igual a ", $valor1 - $val2;
}else if($op == 'op3'){
echo "O resultado è igual a ", $valor1 * $val2;
}else if($op == 'op4'){
echo "O resultado é igual a ", $valor1 / $val2;
}
?>
