﻿<?php

$a=$_POST['txtNum'];
if( $a %2!=0){
echo "$a é impar";
}else{
echo "$a é par";
}



?>