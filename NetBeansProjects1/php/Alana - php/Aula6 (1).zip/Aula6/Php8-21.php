﻿<?php

	echo "Multiplicação <br> ";
	
	$valor1= $_POST['txtValor1'];
	$valor2= $_POST['txtValor2'];
	$resultado= ($valor1*$valor2);
	
	if  ($valor1 && $valor2 != 0){
		echo "$valor1 X $valor2 <br> O resultado é: $resultado";
	}else 
		echo "Digite valores diferentes de 0";
		
?>