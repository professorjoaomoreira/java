﻿<?php

	echo "Boletim <br> ";
		
	$nota1= $_POST['txtValor1'];
	$nota2= $_POST['txtValor2'];
	$nota3= $_POST['txtValor3'];
	$nota4= $_POST['txtVarol4'];
	$media = ($nota1+$nota2+$nota3+$nota4)/4;

	echo "Sua média é: $media <br>"; 
	if ( $media >= 7 ){
		echo "Aprovado!!";
	}else 
		echo  "Reprovado!!" ;
		
?>