﻿<html>
<head> <title> Exercicio 16 </title> </head>
<link href="f1.css" rel="stylesheet" type="text/css">

<body background="form16.jpg">

<div id="formulario">
    <center><h1> Exercicio 16 </h1></center>

<?php

$Valor1=$_POST['txtValor1'];


if (  $Valor1 >= 20 && $Valor1 <= 90  )
{
  echo "O número $Valor1 está entre 20 e 90!";
}
  else { echo "O número $Valor1 não está entre 20 e 90!";
}
?>

</div>
</body>
</html>