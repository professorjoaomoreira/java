﻿<?php
	$numero = $_POST['txtNum'];
	
	if($numero >= 20 && $numero <=90){
		echo "O número digitado está na faixa dos 20 a 90";
	}else{
		echo "O número digitado não está na faixa dos 20 a 90";
	}
 
?>