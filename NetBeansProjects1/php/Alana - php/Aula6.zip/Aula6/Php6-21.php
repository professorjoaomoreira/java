﻿<?php

	echo "Lucro ou Prejuízo <br> ";
	
	$despesa_agua= $_POST['txtAgua'];
	$despesa_luz= $_POST['txtLuz'];
	$lucro= $_POST['txtLucro'];
	$resultado = ($despesa_agua + $despesa_luz);

	if ( $resultado < $lucro ){
		echo " tá no lucro  ;)";
	}else 
		echo  "tá no preju :( " ;
?>