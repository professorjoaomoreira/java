﻿<?php	

	echo "Maior ou Menor que 100<br> ";
	
	$valor1= $_POST['txtValor1'];

	if  ($valor1 >= 100){
		echo "$valor1 é maior que 100";
	}else
		echo "$valor1 é menor que 100";
?>