﻿<?php 
	$nota1=$_POST['txtNota1'];
	$nota2=$_POST['txtNota2'];
	$nota3=$_POST['txtNota3'];
	
	$media= ($nota1+$nota2+$nota3)/3;
	
	if($media >= 9 && $media <= 10){
		echo "Conceito A";
	}elseif($media >=7 && $media < 9){
		echo "Conceito B";
	}elseif($media >=4 && $media < 7){
		echo "Conceito C";
	}else{
		echo "Conceito D";
	}
	
?>
