﻿<?php 
	$qi = $_POST['txtQi'];
	
	if($qi >= 0 && $qi < 30){
		echo "Ameba";
	}elseif($qi >= 30 && $qi <50){
		echo "Débil mental";
	}elseif($qi >=50 && $qi < 70){
		echo "Regular";
	}elseif($qi >=70 && $qi < 100){
		echo "Normal";
	}elseif($qi >=100 && $qi <=150){
		echo "Gênio";
	}else{
		echo "QI inválido";
	}
?>