﻿<?php
	$num= $_POST['txtNum']; 
	
	if ($num == 1){
		echo "Sabão";
	}elseif($num== 2){
		echo "Vassoura";
	}else{
		echo "Detergente";
	}

?>