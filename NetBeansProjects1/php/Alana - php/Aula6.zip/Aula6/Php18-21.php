﻿<?php
	$sexo= $_POST['txtSexo']; 
	
	if ($sexo == 1){
		echo "Masculino";
	}elseif($sexo == 2){
		echo "Feminino";
	}else{
		echo "Código inválido";
	}

?>