<?php
	
	echo "Tabela dos jogos <br> <br> ";
	
	$Vitorias= $_POST['txtVitorias'];
	$Derrotas= $_POST['txtDerrotas'];
	$Empates=  $_POST['txtEmpates'];
	$Empates= 1; 
	$pontos = ($Vitorias * 3)+ $Empates;

	echo "Pontuação Total -- $pontos <br> <br>";

	if ( $Derrotas <= $Vitorias ){ 
		echo "DESEMPENHO BOM";
    }else
		echo  "DESEMPENHO RUIM";

   ?>