﻿<?php
	$angulo = $_POST['txtNum'];
	
	if($angulo > 0 && $angulo < 90){
		echo "Ângulo no primeiro quadrante";
	}elseif($angulo > 90 && $angulo < 180){
		echo "Ângulo no segundo quadrante";
	}elseif($angulo > 180 && $angulo < 270){
		echo "Ângulo no terceiro quadrante";
	}else{
		echo "Ângulo no quarto quadrante";
	}
 
?>