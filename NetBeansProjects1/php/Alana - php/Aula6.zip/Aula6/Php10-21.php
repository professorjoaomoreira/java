<?php

	echo "Pare ou Siga<br> ";
	
	$opcao = $_POST['escolha1'];
	
	if  ($opcao == "opcao1") {
		echo  "Aguarde";
	}
		else echo "Siga";
?>