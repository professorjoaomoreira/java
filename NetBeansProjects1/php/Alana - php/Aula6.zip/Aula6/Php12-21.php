﻿<?php 
	$salario=$_POST['txtSal'];
	
	if($salario <= 500){
		$salario = $salario * 1.15;
		echo "Você recebeu um reajuste de 15%, e seu salário passa a ser de: $salario";
	}elseif ($salario == 500 && $salário <= 1000){
		$salario = $salario * 1.10;
		echo "Você recebeu um reajuste de 10%, e seu salário passa a ser de: $salario";
	}else{
		$salario = $salario * 1.05;
		echo "Você recebeu um reajuste de 5%, e seu salário passa a ser de: $salario";
	}
?>