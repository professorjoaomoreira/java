﻿<?php

$a= $_POST['Num1'];
$b= $_POST ['Num2'];

if($a>$b){
echo "$a eh maior";
}else{
echo "$b eh maior";
}

?>