﻿<?php 
	$valor_hora=$_POST['txtValorHora'];
	$qtdade_hora=$_POST['txtHoras'];
	$filhos=$_POST['txtFilhos'];
	
	$sal_Bruto= $valor_hora * $qtdade_hora;
	
	if($sal_Bruto == 500){
		$sal_Familia = $sal_Bruto +($filhos * 10.50);
		echo " Seu Salário Bruto é de: $sal_Bruto <br> Seu Salário Família é de: $sal_Familia";
	}elseif($sal_Bruto > 500 && $sal_Bruto == 1000){
		$sal_Familia = $sal_Bruto +($filhos * 6.50);
		echo " Seu Salário Bruto é de: $sal_Bruto <br> Seu Salário Família é de: $sal_Familia";
	}else{
		$sal_Familia = $sal_Bruto +($filhos * 1.50);
		echo " Seu Salário Bruto é de: $sal_Bruto <br> Seu Salário Família é de: $sal_Familia";
	}
?>