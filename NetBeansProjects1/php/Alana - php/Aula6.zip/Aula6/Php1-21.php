<?php
$a=$_POST['Val1'];
$b=$_POST['Val2'];

$soma=$a+$b;

if($soma >= 10){
echo "Sua $soma é:";
}else{
echo "Sua $soma é maior ou igual a 10.";
 
}


?>