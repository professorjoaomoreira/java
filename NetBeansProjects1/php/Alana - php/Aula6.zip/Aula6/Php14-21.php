﻿<?php
	$valor_hora=$_POST['txtValorHora'];
	$qtdade_hora=$_POST['txtHoras'];
	
	$sal_Bruto= $valor_hora * $qtdade_hora;
	
	if($sal_Bruto == 500){
		$desconto= $sal_Bruto * 0.08;
		$sal_Liq = $sal_Bruto - $desconto;
		echo"Seu Salário Bruto é: $sal_Bruto .<br> Sua taxa de INSS é de 8%. <br> O valor do INSS é de: $desconto . <br> Assim, seu Salário Líquido é de: $sal_Liq .";
	}elseif($sal_Bruto > 500 && $sal_Bruto == 1000){
		$desconto= $sal_Bruto * 0.10;
		$sal_Liq = $sal_Bruto - $desconto;
		echo"Seu Salário Bruto é: $sal_Bruto .<br> Sua taxa de INSS é de 10%. <br> O valor do INSS é de: $desconto . <br> Assim, seu Salário Líquido é de: $sal_Liq .";
	}else{
		$desconto= $sal_Bruto * 0.12;
		$sal_Liq = $sal_Bruto - $desconto;
		echo"Seu Salário Bruto é: $sal_Bruto .<br> Sua taxa de INSS é de 12%. <br> O valor do INSS é de: $desconto . <br> Assim, seu Salário Líquido é de: $sal_Liq .";
	}
?>