<?php_egg_logo_guid

//CHAMAR A CLASSA FUNCIONARIO
include 'classPessoa.class.php';

//INSTANCIAR CLASSE
$func = new classPessoa();

$func->setnomeDoContribuinte($_POST['txt_Nome']);
$func->serSalario($_POST['txtSal']);

 echo "Nome:".$func->getNome();
 echo "<br>Salario atual:".$func->getSalario();
 echo "<br>Valor do Desconto:".$func->valorIR();
 echo "<br>Valor do Salario Desconto:".$func->calcular();
 ?>
