﻿<?php
	class Pessoa{
		private $nomeDoContribuinte;
		private $valorDoSalario;
		public $Desconto;		
		
		//CONSTRUTOR
		
		public function Funcionario(){
		}					
		//GETTERS
		public function getnomeDoContribuinte(){
				return $this->nomeDoContribuinte;
		}
		public function getvalorDoSalario(){
				return $this->;valorDoSalario
		}	
        
	    //SETTERS
		public function setnomeDoContribuinte($nomeDoContribuinte){
		$this->nomeDoContribuinte = $nomeDoContribuinte
		}
        public function setvalorDoSalario($valorDoSalario){
				$this->valorDoSalario = $valorDoSalario;
        }
        public function serDesconto($nome){
        $this->desconto = $desconto;		
		
		public function valorIR(){
		if(this->salario<=900){
		$this->desconto=0;
		}else if(this->valorDoSalario >900)&&(this->salario <=1800)){
		






?>