<?php 
	include 'aula7exe2.class.php';
	
	$area = new Area();
	$area->setCSala($_POST['txtCSala']);
	$area->setLSala ($_POST['txtLSala']);
	$area->setCcozinha($_POST['txtCCozinha']);
	$area->setLCozinha ($_POST['txtLCozinha']);
	$area->setCBanheiro($_POST['txtCBanheiro']);
	$area->setLBanheiro ($_POST['txtLBanheiro']);
	$area->setCQuarto1($_POST['txtCQua1']);
	$area->setLQuarto1 ($_POST['txtLQua1']);
	$area->setCQuarto2($_POST['txtCQua2']);
	$area->setLQuarto2 ($_POST['txtLQua2']);
	$area->setCAreaS($_POST['txtCAreaS']);
	$area->setLAreaS ($_POST['txtLAreaS']);
	$area->setCQuintal($_POST['txtCQuintal']);
	$area->setLQuintal ($_POST['txtLQuintal']);
	$area->setCGaragem($_POST['txtCGaragem']);
	$area->setLGaragem ($_POST['txtLGaragem']);
	
	
	echo 'Área da sala: '.$area->areaSala() .'<br>';
	echo 'Área da cozinha: '.$area->areaCozinha() .'<br>';
	echo 'Área do banheiro: '.$area->areaBanheiro() .'<br>';
	echo 'Área do quarto 1: '.$area->areaQuarto1() .'<br>';
	echo 'Área do quarto 2: '.$area->areaQuarto2() .'<br>';
	echo 'Área da área social: '.$area->areaAreaS() .'<br>';
	echo 'Área do quintal: '.$area->areaQuintal() .'<br>';
	echo 'Área da garagem: '.$area->areaGaragem() .'<br>';
	echo 'Área total: '.$area->areaTotal() .'<br>';
?>