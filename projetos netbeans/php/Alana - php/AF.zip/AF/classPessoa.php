<?php
	class Pessoa{
		private $nomeDoContribuinte;
		private $valorDoSalario;
		public $Desconto;
		
		
		public function getnomeDoContribuinte(){
				return $this->nomeDoContribuinte;
		}
		public function setnomeDoContribuinte($nomeDoContribuinte){
				$this->nomeDoContribuinte = $nomeDoContribuinte
		}
		public function getvalorDoSalario(){
				return $this->;valorDoSalario
		}
		public function setvalorDoSalario($valorDoSalario){
				$this->valorDoSalario = $valorDoSalario;
}

public function CalcularDesconto(){

      if($this->$valorDoSalario<=900){
      return $this->valorDoSalario
}

public function CalcularDesconto>=1800){
retun $this->valorSalario-15%
}

public function CalcularImposto(){
retun $this->$CalcularImposto=$valorDoSalario-$Desconto;
?>