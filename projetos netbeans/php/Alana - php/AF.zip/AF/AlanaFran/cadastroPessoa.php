<html>
	<head>
		<title>Cadastro Pessoa</title>
	</head>
	
	<body> 
	 <fieldset><form action="classPessoa.php" method="post">
						
	<label>Nome Do Contribuinte:<input type="text" name="txtnome"/><br>
   <label>Valor do Salário:<input type="text" name="txvalorSalario"/><br>
				
		
						<br>
   <input type="submit" name="btncalcular" value="calcular">
   <input type="reset" name="btnlimpar" value="limpar">
			
</fieldset>			
			
		<form>
	</body>
	
</html>