<?php

	$a=$_POST['N1'];
	$b=$_POST['N2'];
	$c=$_POST['N3'];
	$d=$_POST['N4'];
	

	if($a+$b+$c+$d>=7){
     echo "APROVADO";
	}else{
	echo "REPROVADO";
	}

?>