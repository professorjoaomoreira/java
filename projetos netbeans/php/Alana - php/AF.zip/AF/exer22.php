<?php
	class Area{
		private $Csala;
		private $Ccozinha;
		private $Cbanheiro;
		private $Cquarto1;
		private $Cquarto2;
		private $CareaS;
		private $Cquintal;
		private $Cgaragem;
		private $Lsala;
		private $Lcozinha;
		private $Lbanheiro;
		private $Lquarto1;
		private $Lquarto2;
		private $LareaS;
		private $Lquintal;
		private $Lgaragem;
		private $areaTotal;
		
		
		
		public function Area(){
		}
		
		public function getAreaTotal(){
			return $this->areaTotal;
		}
		
		public function setAreaTotal($areaTotal){
			$this->areaTotal=$areaTotal;
		}
		
		public function getCSala(){
			return $this->sala;
		}
		
		public function setCSala($Csala){
			$this->Csala=$Csala;
		}
		
		public function getCCozinha(){
			return $this->Ccozinha;
		}
		
		public function setCCozinha($Ccozinha){
			$this->Ccozinha=$Ccozinha;
		}
		
		public function getCBanheiro(){
			return $this->Cbanheiro;
		}
		
		public function setCBanheiro($Cbanheiro){
			$this->Cbanheiro=$Cbanheiro;
		}
		
		public function getCQuarto1(){
			return $this->Cquarto1;
		}
		
		public function setCQuarto1($Cquarto1){
			$this->Cquarto1=$Cquarto1;
		}
		
		public function getCQuarto2(){
			return $this->Cquarto2;
		}
		
		public function setCQuarto2($Cquarto2){
			$this->Cquarto2=$Cquarto2;
		}
		
		public function getCAreaS(){
			return $this->CareaS;
		}
		
		public function setCAreaS($CareaS){
			$this->CareaS=$CareaS;
		}
		
		public function getCQuintal(){
			return $this->Cquintal;
		}
		
		public function setCQuintal($Cquintal){
			$this->Cquintal=$Cquintal;
		}
		
		public function getCGaragem(){
			return $this->Cgaragem;
		}
		
		public function setCGaragem($Cgaragem){
			$this->Cgaragem=$Cgaragem;
		}
		
		public function getLSala(){
			return $this->Lsala;
		}
		
		public function setLSala($Lsala){
			$this->Lsala=$Lsala;
		}
		
		public function getLCozinha(){
			return $this->Lcozinha;
		}
		
		public function setLCozinha($Lcozinha){
			$this->Lcozinha=$Lcozinha;
		}
		
		public function getLBanheiro(){
			return $this->Lbanheiro;
		}
		
		public function setLBanheiro($Lbanheiro){
			$this->Lbanheiro=$Lbanheiro;
		}
		
		public function getLQuarto1(){
			return $this->Lquarto1;
		}
		
		public function setLQuarto1($Lquarto1){
			$this->Lquarto1=$Lquarto1;
		}
		
		public function getLQuarto2(){
			return $this->Lquarto2;
		}
		
		public function setLQuarto2($Lquarto2){
			$this->Lquarto2=$Lquarto2;
		}
		
		public function getLAreaS(){
			return $this->LareaS;
		}
		
		public function setLAreaS($LareaS){
			$this->LareaS=$LareaS;
		}
		
		public function getLQuintal(){
			return $this->Lquintal;
		}
		
		public function setLQuintal($Lquintal){
			$this->Lquintal=$Lquintal;
		}
		
		public function getLGaragem(){
			return $this->Lgaragem;
		}
		
		public function setLGaragem($Lgaragem){
			$this->Lgaragem=$Lgaragem;
		}
		
		public function areaSala(){
			$this->areaTotal += $this->Csala * $this->Lsala;
			return $this->Csala * $this->Lsala;
		}
		
		public function areaCozinha(){
			$this->areaTotal += $this->Ccozinha * $this->Lcozinha;
			return $this->Ccozinha * $this->Lcozinha;
		}
		
		public function areaBanheiro(){
			$this->areaTotal += $this->Cbanheiro * $this->Lbanheiro;
			return $this->Cbanheiro * $this->Lbanheiro;
		}
		
		public function areaQuarto1(){
			$this->areaTotal += $this->Cquarto1 * $this->Lquarto1;
			return $this->Cquarto1 * $this->Lquarto1;
		}
		
		public function areaQuarto2(){
			$this->areaTotal += $this->Cquarto2 * $this->Lquarto2;
			return $this->Cquarto2 * $this->Lquarto2;
		}
		
		public function areaAreaS(){
			$this->areaTotal += $this->CareaS * $this->LareaS;
			return $this->CareaS * $this->LareaS;
		}
		
		public function areaQuintal(){
			$this->areaTotal += $this->Cquintal * $this->Lquintal;
			return $this->Cquintal * $this->Lquintal;
		}
		
		public function areaGaragem(){
			$this->areaTotal += $this->Cgaragem * $this->Lgaragem;
			return $this->Cgaragem * $this->Lgaragem;
		}
		
		public function areaTotal(){
			return $this->areaTotal ;
		}
	
	}
?> 



