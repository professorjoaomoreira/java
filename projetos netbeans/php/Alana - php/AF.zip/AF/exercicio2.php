﻿<?php
	private CQuarto1;
	private LQuarto1;
	private CQuarto2;
	private LQuarto2;
	private CSala;
	private LSala;
	private CCozinha;
	private LCozinha;
	private CBanheiro;
	private LBanheiro;

	public function areaQuarto1(){
		return $this->CQuarto1*$this->LQuarto1;
	}

	public function areaQuarto2(){
		return $this->CQuarto2*$this->LQuarto2;
	}

	public function areaSala(){
		return $this->CSala*$this->LSala;
	}

	public function areaCozinha(){
		return $this->CCozinha*$this->LCozinha;
	}

	public function areaBanheiro(){
		return $this->CBanheiro*$this->LBanheiro;
	}

	public function getQuarto1(){	
		return $this->;Quarto1
		}	
	public function setCQuarto1($LQuarto1){
		$this->LQuarto1 = $LQuarto1;
	
	
	public function getQuarto2(){	
		return $this->;Quarto2
		}	
	public function setCQuarto2($LQuarto2){
		$this->LQuarto2 = $LQuarto2;
    
	
	public function getCSala(){	
		return $this->;CSala;
		}		
	public function setCSala($CSala){
		$this->CSala = $CSala;		
		
	
	public function getLSala(){	
		return $this->;LSala;
		}		
	public function setLSala($LSala){
		$this->LSala = $LSala;	
		
	
	public function getLCozinha(){	
		return $this->;LCozinha;
		}		
	public function setLCozinha($LCozinha){
		$this->LCozinha = $LCozinha;
		
	
	public function getCCozinha(){	
		return $this->;CCozinha;
		}		
	public function setCCozinha($CCozinha){
		$this->CCozinha = $CCozinha;
	
	public function getCBanheiro(){	
		return $this->;CBanheiro;
		}		
	public function setCBanheiro($CBanheiro){
		$this->CBanheiro = $CBanheiro;		

		
    public function getLBanheiro(){	
		return $this->;LBanheiro;
		}		
	public function setLBanheiro($LBanheiro){
		$this->LBanheiro = $LBanheiro;
    	
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

?>