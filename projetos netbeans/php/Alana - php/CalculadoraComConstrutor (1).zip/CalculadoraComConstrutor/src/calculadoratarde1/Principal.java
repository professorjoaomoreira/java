/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package calculadoratarde1;

import javax.swing.JOptionPane;
import modelo.Calculadora;

/**
 * @author Thiago Cury
 * @since 14/03/2013 - 14:17
 * @version 1.0 Ryu
 */
public class Principal {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        /* Recebendo o primeiro valor do usuário e inserindo na variável
          num1. O valor entra como String no JOptionPane e é convertido para
          double através do método parseDouble. */
        double num1 = 
                Double.parseDouble(
                    JOptionPane.showInputDialog(null,
                        "Digite o primeiro número: "));
        
        /* Recebendo o segundo valor do usuário e inserindo na variável
          num2. O valor entra como String no JOptionPane e é convertido para
          double através do método parseDouble. */
        double num2 =
                Double.parseDouble(
                    JOptionPane.showInputDialog(null,
                        "Digite o segundo número: "));
        
        /* Instanciando um objeto calc a partir da Classe Calculadora e 
           enviando as duas variáveis (num1 e num2) como parametro. */
        Calculadora calc = new Calculadora(num1, num2);
        
        
        /* Enviando um menu para o usuário decidir 
         * o que ele deseja visualizar */
        int op =  Integer.parseInt(
                        JOptionPane.showInputDialog(
                            null,
                            "Digite:\n"
                          + "1-somar\n"
                          + "2-subtrair\n"
                          + "3-dividir\n"
                          + "4-multiplicar"));
        
        //Testando o valor digitado pelo usuário através de um switch
        switch(op){
            case 1: 
                JOptionPane.showMessageDialog(null,
                        "soma: "+calc.somar());
                break;
            case 2:
                JOptionPane.showMessageDialog(null,
                        "subtraçãor: "+calc.subtrair());
                break;
            case 3:
                JOptionPane.showMessageDialog(null,
                        "divisão: "+calc.dividir());
                break;                
                
            case 4:
                JOptionPane.showMessageDialog(null,
                        "multiplicação: "+calc.multiplicar());
                break;                
            default:
                JOptionPane.showMessageDialog(null,
                        "opção inválida");
                break;
        }//fecha switch
    }//fecha método main
}//fecha classe