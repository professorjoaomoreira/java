/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package calculadoramanha02;

import javax.swing.JOptionPane;

/**
 *
 * @author Thiago Cury
 * @since 16/05/2013 - 09:17
 * @version 1.0 Beta
 */
public class Calculadora {

    //Atributos da classe
    private double numero1;
    private double numero2;

    //Métodos construtores
    public Calculadora() {
    }

    /**
     *
     * @param numero1 recebe o primeiro número
     * @param numero2 recebe o segundo número
     */
    public Calculadora(double numero1, double numero2) {
        this.numero1 = numero1;
        this.numero2 = numero2;
    }

    //Métodos acessores
    public double getNumero2() {
        return numero2;
    }

    public void setNumero2(double numero2) {
        this.numero2 = numero2;
    }

    public double getNumero1() {
        return numero1;
    }

    public void setNumero1(double numero1) {
        this.numero1 = numero1;
    }

    //Métodos de calculo
    /**
     *
     * @return retorna a soma entre numero1 e numero2
     */
    public double somar() {
        return numero1 + numero2;
    }

    /**
     *
     * @return retorna a subtração entre numero1 e numero2
     */
    public double subtrair() {
        return numero1 - numero2;
    }

    /**
     *
     * @return retorna a multiplicação entre numero1 e numero2
     */
    public double multiplicar() {
        return numero1 * numero2;
    }

    /**
     *
     * @return retorna a divisão entre numero1 e numero2
     */
    public double dividir() {
        return numero1 / numero2;
    }

    /**
     * 
     * @param op - Recebe a opção que o usúario escolheu no menu
     * @return Retorna a operação desejada pelo usuário.
     */
    public String menu(int op) {
        if (op == 1) {
            return "soma: " + somar();
        } else if(op == 2){
            return "subtração: " + subtrair();
        } else if(op == 3){
            return "multiplicação: " + multiplicar();
        } else if(op == 4){
            return "divisão " + dividir();
        } else {
            return "opção inválida!";
        }
    }

    @Override
    public String toString() {
        return "Resposta: "
                + "\nsoma: " + somar()
                + "\nsubtração: " + subtrair()
                + "\ndivisão: " + dividir()
                + "\nmultiplicação: " + multiplicar();

    }
}
