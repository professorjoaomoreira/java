/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package calculadoramanha02;

import javax.swing.JOptionPane;

/**
 *
 * @author Thiago Cury
 * @since 16/05/2013 - 09:42
 * @version 1.0 Beta
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        //SEM CONSTRUTOR
        Calculadora calc1 = new Calculadora();

        calc1.setNumero1(
                Double.parseDouble(
                JOptionPane.showInputDialog(
                null,
                "Digite o primeiro número: ",
                "calculadora",
                JOptionPane.QUESTION_MESSAGE)));

        calc1.setNumero2(
                Double.parseDouble(
                JOptionPane.showInputDialog(
                null,
                "Digite o segundo número: ",
                "calculadora",
                JOptionPane.QUESTION_MESSAGE)));

        int op = Integer.parseInt(
                        JOptionPane.showInputDialog(
                            null,
                            "Digite:"
                          + "\n1-somar"
                          + "\n2-subtrair"
                          + "\n3-multiplicar"
                          + "\n4-dividir"));

        JOptionPane.showMessageDialog(
                null, 
                calc1.menu(op),
                "relatório",
                JOptionPane.PLAIN_MESSAGE);

    }//fecha main
}//fecha classe

