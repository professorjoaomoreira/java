﻿<?php

$frutas = array(
		1=>"Laranja",
		2=>"Maça",
		3=>"Uva",
		
		
		echo "<li>$frutas[1]<br>";
		echo "<li>$frutas[2]<br>";
		echo "<li>$frutas[3]<br>";
?>