﻿<?php

$a=10;
$b=15;

$c= $a+$b;

echo "$a mais $b é igual a $c"






?>