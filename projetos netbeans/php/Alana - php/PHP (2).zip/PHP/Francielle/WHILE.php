﻿<?php
$i =1;
while ($i<10000)
{
echo($i);
$i *=2;
echo (" Vezes dois é igual a $i <br>");
}

?>