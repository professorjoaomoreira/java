﻿<?php

echo"PRIMEIRA PÁGINA EM PHP";






?>