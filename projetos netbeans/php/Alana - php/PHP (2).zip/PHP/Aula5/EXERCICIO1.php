﻿<?php

$a=50;
$b=30;
$c=10;

$d=$a+$b*$c;
echo "$a mais $b vezes $c é igual a $d"
?>