<?php

	$a=$_POST['txtRes1'];
	$b=$_POST['txtRes2'];

	if($a>$b){
	$a/=$b;
	echo "A divisão é igual a $a";
	}else{
	echo "A divisão é igual a #b;
	}

?>