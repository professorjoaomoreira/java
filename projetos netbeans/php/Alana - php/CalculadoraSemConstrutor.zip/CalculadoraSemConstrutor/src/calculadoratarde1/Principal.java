/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package calculadoratarde1;

import javax.swing.JOptionPane;
import modelo.Calculadora;

/**
 * @author Thiago Cury
 * @since 14/03/2013 - 14:17
 * @version 1.0 Ryu
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        /* Instanciando um objeto calc vazio na memória */
        Calculadora calc = new Calculadora();

        /* Recebendo o primeiro valor do usuário e inserindo no atributo
         num1 do objeto calc através do método setNum1.
         O valor entra como String no JOptionPane e é convertido para
         double através do método parseDouble. */
        calc.setNum1(
                Double.parseDouble(
                JOptionPane.showInputDialog(null,
                "Digite o primeiro número: ")));

        /* Recebendo o segundo valor do usuário e inserindo no atributo
         num2 do objeto calc através do método setNum2. */
        calc.setNum2(
                Double.parseDouble(
                JOptionPane.showInputDialog(null,
                "Digite o segundo número: ")));

        /* Enviando um menu para o usuário decidir 
         * o que ele deseja visualizar */
        int op = Integer.parseInt(
                JOptionPane.showInputDialog(
                null,
                "Digite:\n"
                + "1-somar\n"
                + "2-subtrair\n"
                + "3-dividir\n"
                + "4-multiplicar"));

        //Testando o valor digitado pelo usuário através de estrutura if
        if (op == 1) {
            JOptionPane.showMessageDialog(null,
                    "soma: " + calc.somar());
        } else if (op == 2) {
            JOptionPane.showMessageDialog(null,
                    "subtraçãor: " + calc.subtrair());
        } else if (op == 3) {
            JOptionPane.showMessageDialog(null,
                    "divisão: " + calc.dividir());
        } else if (op == 4) {
            JOptionPane.showMessageDialog(null,
                    "multiplicação: " + calc.multiplicar());
        } else {
            JOptionPane.showMessageDialog(null,
                    "opção inválida");
        }//fecha else

    }//fecha método main
}//fecha classe